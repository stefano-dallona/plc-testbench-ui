# Free images can be found at https://uxwing.com/analyze-sound-wave-icon/
# No attribution or credit needed